import numpy as np
def cnst(i:int):
    return int(np.round(np.exp(2*np.pi*1j*0.999).real*i))